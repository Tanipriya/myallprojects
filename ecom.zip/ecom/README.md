[![html](https://img.shields.io/badge/html-red?style=for-the-badge&logo=HTML5&logoColor=white)]()
[![CSS](https://img.shields.io/badge/css-blue?style=for-the-badge&logo=css&logoColor=white)]()




[![](https://img.shields.io/badge/linkedin-blue?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/tanishapriya/)
[![](https://img.shields.io/badge/MY%20PORTFOLIO-0B94DE?style=for-the-badge)](https://tanishapriya.tech/ 'Link')



<!-- [![]()]() -->
# Complete Ecommerce Task

## **Using Technology**
<!-- [![react](https://img.shields.io/badge/React-blue?style=for-the-badge&logo=react&logoColor=white)]() -->
<!-- [![tailwind css](https://img.shields.io/badge/tailwind%20css-blue?style=for-the-badge&logo=tailwind%20css&logoColor=white)]() -->
[![Api](https://img.shields.io/badge/Api-green?style=for-the-badge&logo=api&logoColor=white)]()
[![Javascript](https://img.shields.io/badge/javascript-white?style=for-the-badge&logo=javascript&logoColor=yellow)]()


# 🚀[Ecommerce Live Project](https://main--tubular-centaur-d76add.netlify.app/) this is live
![ecommerce](./Screenshot%202024-01-12%20124651.png)
![ecommerce](./Screenshot%202024-01-12%20124707.png)


next....